-- MySQL dump 10.13  Distrib 5.1.73, for redhat-linux-gnu (x86_64)
--
-- Host: localhost    Database: paxtasanoat_db
-- ------------------------------------------------------
-- Server version	5.1.73

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `paxtasanoat_db`
--


--
-- Table structure for table `charges`
--

DROP TABLE IF EXISTS `charges`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `charges` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `currency_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `output_summ` double NOT NULL,
  `charges_type_id` int(11) NOT NULL,
  `description` text COLLATE utf8_bin NOT NULL,
  UNIQUE KEY `id` (`id`),
  KEY `currency_id` (`currency_id`),
  KEY `charges_type_id` (`charges_type_id`),
  CONSTRAINT `charges_ibfk_1` FOREIGN KEY (`currency_id`) REFERENCES `currency` (`id`),
  CONSTRAINT `charges_ibfk_2` FOREIGN KEY (`charges_type_id`) REFERENCES `charges_types` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `charges`
--

LOCK TABLES `charges` WRITE;
/*!40000 ALTER TABLE `charges` DISABLE KEYS */;
INSERT INTO `charges` VALUES (3,1,'2018-01-01',2000,2,'Paxtasanoat Toshkent, Texnik chigit, Paxta momig\'i, Paxta tolasi'),(4,3,'2017-11-30',6000,8,''),(5,2,'2017-11-14',300000,2,''),(6,3,'2018-01-15',90000,2,'jklfdjklgjfsdkl'),(7,1,'2017-01-04',5000,4,''),(8,3,'2017-11-30',50000,8,''),(9,3,'2017-11-23',5000,2,''),(10,1,'2018-03-27',324234,3,'234');
/*!40000 ALTER TABLE `charges` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `charges_types`
--

DROP TABLE IF EXISTS `charges_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `charges_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `charges_types`
--

LOCK TABLES `charges_types` WRITE;
/*!40000 ALTER TABLE `charges_types` DISABLE KEYS */;
INSERT INTO `charges_types` VALUES (1,'Markaziy bankga'),(2,'Jamg\'armaga'),(3,'Солиқ ва ажратмалар'),(4,'Иш ҳақи'),(5,'Электр энергия'),(6,'Дойче кабел'),(7,'ЁММ'),(8,'Пахта инвест'),(9,'Банк кредитларига'),(10,'Банк хизмати'),(11,'Ўров материаллари'),(12,'Транспорт хизмати'),(13,'Ўрта Осиё транс'),(14,'Кимёвий препаратлар');
/*!40000 ALTER TABLE `charges_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ci_sessions`
--

DROP TABLE IF EXISTS `ci_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ci_sessions` (
  `id` varchar(128) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `timestamp` int(10) unsigned NOT NULL DEFAULT '0',
  `data` blob NOT NULL,
  KEY `ci_sessions_timestamp` (`timestamp`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ci_sessions`
--

LOCK TABLES `ci_sessions` WRITE;
/*!40000 ALTER TABLE `ci_sessions` DISABLE KEYS */;
INSERT INTO `ci_sessions` VALUES ('5jul9ssmkbfoptafv6ajdbd19jeh6apn','::1',1515098098,'__ci_last_regenerate|i:1515097652;identity|s:5:\"admin\";username|s:5:\"admin\";email|s:15:\"admin@admin.com\";user_id|s:1:\"1\";old_last_login|s:10:\"1515084649\";last_check|i:1515097654;'),('669g81cdos69nifail17jehcru7j74fo','::1',1515173932,'__ci_last_regenerate|i:1515173843;identity|s:5:\"admin\";username|s:5:\"admin\";email|s:15:\"admin@admin.com\";user_id|s:1:\"1\";old_last_login|s:10:\"1515097654\";last_check|i:1515173883;'),('greeb5j7kue1scbd8g5oifi34a3fi477','::1',1515182305,'__ci_last_regenerate|i:1515182228;identity|s:5:\"admin\";username|s:5:\"admin\";email|s:15:\"admin@admin.com\";user_id|s:1:\"1\";old_last_login|s:10:\"1515173883\";last_check|i:1515182233;'),('15l1cnfm90r0ujh0qo3ivkb6nrqsn6u5','::1',1515187175,'__ci_last_regenerate|i:1515186884;identity|s:5:\"admin\";username|s:5:\"admin\";email|s:15:\"admin@admin.com\";user_id|s:1:\"1\";old_last_login|s:10:\"1515173883\";last_check|i:1515182233;'),('a9omqsdh7kohdmb6cjkqncvconrjfeu8','::1',1515187441,'__ci_last_regenerate|i:1515187191;identity|s:5:\"admin\";username|s:5:\"admin\";email|s:15:\"admin@admin.com\";user_id|s:1:\"1\";old_last_login|s:10:\"1515173883\";last_check|i:1515182233;'),('pdmd6cajl8j5h406mhd9cbe6g5d0u5e8','::1',1515187653,'__ci_last_regenerate|i:1515187537;identity|s:5:\"admin\";username|s:5:\"admin\";email|s:15:\"admin@admin.com\";user_id|s:1:\"1\";old_last_login|s:10:\"1515173883\";last_check|i:1515182233;'),('kanfpcsm18lqku6jonc7rqglp0b673sm','::1',1515208576,'__ci_last_regenerate|i:1515208165;identity|s:5:\"admin\";username|s:5:\"admin\";email|s:15:\"admin@admin.com\";user_id|s:1:\"1\";old_last_login|s:10:\"1515182233\";last_check|i:1515208171;'),('j0ue13b0gera6v4un1j7mngq1pvb7e00','::1',1515209604,'__ci_last_regenerate|i:1515209540;identity|s:5:\"admin\";username|s:5:\"admin\";email|s:15:\"admin@admin.com\";user_id|s:1:\"1\";old_last_login|s:10:\"1515182233\";last_check|i:1515208171;'),('nkolmh2e0os4knteeiu9542ksrqvula5','::1',1515210406,'__ci_last_regenerate|i:1515210108;identity|s:5:\"admin\";username|s:5:\"admin\";email|s:15:\"admin@admin.com\";user_id|s:1:\"1\";old_last_login|s:10:\"1515182233\";last_check|i:1515208171;'),('oagcph55our12bjm5mboh8115m3igefl','::1',1515210660,'__ci_last_regenerate|i:1515210428;identity|s:5:\"admin\";username|s:5:\"admin\";email|s:15:\"admin@admin.com\";user_id|s:1:\"1\";old_last_login|s:10:\"1515182233\";last_check|i:1515208171;'),('h1c0r9n72mq6semp4rhk0dag9v5djfce','::1',1515211101,'__ci_last_regenerate|i:1515210738;identity|s:5:\"admin\";username|s:5:\"admin\";email|s:15:\"admin@admin.com\";user_id|s:1:\"1\";old_last_login|s:10:\"1515182233\";last_check|i:1515208171;'),('f7purrvijgrhfjhg8e1d9nc18f4j06q2','::1',1515211307,'__ci_last_regenerate|i:1515211130;identity|s:5:\"admin\";username|s:5:\"admin\";email|s:15:\"admin@admin.com\";user_id|s:1:\"1\";old_last_login|s:10:\"1515182233\";last_check|i:1515208171;'),('edflvk9i9eamai7mqb18rjr52fi716o8','185.163.24.125',1515233881,'__ci_last_regenerate|i:1515233731;identity|s:5:\"admin\";username|s:5:\"admin\";email|s:15:\"admin@admin.com\";user_id|s:1:\"1\";old_last_login|s:10:\"1515208171\";last_check|i:1515233752;'),('85283jbjd1r5rbl8nmuo1sm0hku3o6cb','185.163.24.125',1515234669,'__ci_last_regenerate|i:1515234501;identity|s:5:\"admin\";username|s:5:\"admin\";email|s:15:\"admin@admin.com\";user_id|s:1:\"1\";old_last_login|s:10:\"1515208171\";last_check|i:1515233752;'),('h9kscfbk7shooi83oo0n948kakkdga6i','185.163.24.125',1515235374,'__ci_last_regenerate|i:1515235346;identity|s:5:\"admin\";username|s:5:\"admin\";email|s:15:\"admin@admin.com\";user_id|s:1:\"1\";old_last_login|s:10:\"1515208171\";last_check|i:1515233752;'),('26k1de6lhpnve5n6a6eeenoqotj3ebdv','94.158.52.230',1515243045,'__ci_last_regenerate|i:1515243045;'),('6rpqmlsr621v5382j67lppdqvel5hubj','149.154.167.170',1516096394,'__ci_last_regenerate|i:1516096392;'),('9m2vvvh4em4i9cii9ramlkid26lsetu4','83.221.180.49',1516096685,'__ci_last_regenerate|i:1516096398;identity|s:5:\"admin\";username|s:5:\"admin\";email|s:15:\"admin@admin.com\";user_id|s:1:\"1\";old_last_login|s:10:\"1515243026\";last_check|i:1516096438;'),('u1vtt2oll5ocjuimj5l1r9vfk6fk2v20','80.80.213.150',1516113726,'__ci_last_regenerate|i:1516112990;identity|s:5:\"admin\";username|s:5:\"admin\";email|s:15:\"admin@admin.com\";user_id|s:1:\"1\";old_last_login|s:10:\"1516096438\";last_check|i:1516113037;'),('b7rtfb7irngu2sn1r4gitri6sahfposd','83.221.180.49',1516611316,'__ci_last_regenerate|i:1516611277;identity|s:5:\"admin\";username|s:5:\"admin\";email|s:15:\"admin@admin.com\";user_id|s:1:\"1\";old_last_login|s:10:\"1516113037\";last_check|i:1516611285;'),('tilaie0gpeoroklpbs5lddhiulq866hc','83.221.180.49',1516615854,'__ci_last_regenerate|i:1516615850;identity|s:5:\"admin\";username|s:5:\"admin\";email|s:15:\"admin@admin.com\";user_id|s:1:\"1\";old_last_login|s:10:\"1516113037\";last_check|i:1516611285;'),('bfbfgmh5mf700meesgis9ml2qk44c2h1','149.154.167.163',1516696498,'__ci_last_regenerate|i:1516696497;'),('81tcq5u1ti7ajclg6r9o4jhgbfrsn672','83.221.180.49',1516696811,'__ci_last_regenerate|i:1516696595;identity|s:5:\"admin\";username|s:5:\"admin\";email|s:15:\"admin@admin.com\";user_id|s:1:\"1\";old_last_login|s:10:\"1516611285\";last_check|i:1516696650;'),('1tl191mluc5848bk8m3bf6617cc25ku8','83.221.180.49',1516949170,'__ci_last_regenerate|i:1516949168;'),('p2ffck14op9rsfe50a7qkni38g897ccm','80.80.221.197',1517576851,'__ci_last_regenerate|i:1517576818;identity|s:5:\"admin\";username|s:5:\"admin\";email|s:15:\"admin@admin.com\";user_id|s:1:\"1\";old_last_login|s:10:\"1516696650\";last_check|i:1517576821;'),('tvmujh7j8asvken826sn66g0mcetpatl','185.163.24.125',1519232006,'__ci_last_regenerate|i:1519231840;identity|s:5:\"admin\";username|s:5:\"admin\";email|s:15:\"admin@admin.com\";user_id|s:1:\"1\";old_last_login|s:10:\"1517576821\";last_check|i:1519231852;'),('7m897rffkrs6hqqiior4goksdse31akr','80.80.221.197',1519302608,'__ci_last_regenerate|i:1519302607;'),('vcj3nu98v28ie2nf4bal4m405vsknnq0','149.154.167.166',1519490629,'__ci_last_regenerate|i:1519490627;'),('6df2f6aes7v73d099qtpd2ka3bmhv0ai','92.99.138.193',1519490690,'__ci_last_regenerate|i:1519490673;identity|s:5:\"admin\";username|s:5:\"admin\";email|s:15:\"admin@admin.com\";user_id|s:1:\"1\";old_last_login|s:10:\"1519231852\";last_check|i:1519490686;'),('05jfh9nprd2a0a8dgqhm78fgfg0ghsdg','185.163.24.99',1519575864,'__ci_last_regenerate|i:1519575832;identity|s:5:\"admin\";username|s:5:\"admin\";email|s:15:\"admin@admin.com\";user_id|s:1:\"1\";old_last_login|s:10:\"1519490686\";last_check|i:1519575835;'),('mlher2lil8udh77rnr0u7nom1vr06rtn','80.80.221.197',1522831842,'__ci_last_regenerate|i:1522831793;identity|s:5:\"admin\";username|s:5:\"admin\";email|s:15:\"admin@admin.com\";user_id|s:1:\"1\";old_last_login|s:10:\"1519575835\";last_check|i:1522831823;'),('dai4va7lerpl9v3p91f1sdfp58sji3pc','80.80.221.197',1524042534,'__ci_last_regenerate|i:1524042496;identity|s:5:\"admin\";username|s:5:\"admin\";email|s:15:\"admin@admin.com\";user_id|s:1:\"1\";old_last_login|s:10:\"1522831823\";last_check|i:1524042500;'),('o47apk08b3f6pag5lnptfl7su6nfe8lr','185.163.24.95',1530389152,'__ci_last_regenerate|i:1530389111;identity|s:5:\"admin\";username|s:5:\"admin\";email|s:15:\"admin@admin.com\";user_id|s:1:\"1\";old_last_login|s:10:\"1524042500\";last_check|i:1530389135;'),('mmj5putrq5aao6ed9mmjj63icds19i8n','149.154.167.168',1530389170,'__ci_last_regenerate|i:1530389170;'),('07af6n3dmr55tqgummamqtv51otqprmp','185.163.24.94',1530461947,'__ci_last_regenerate|i:1530461945;'),('ajj1vl0f8lh5otkbm30kahl2run6fcro','185.163.24.117',1530993220,'__ci_last_regenerate|i:1530993218;'),('rs85nqcqkui8ctdh4au6ks192n75jm9n','185.163.24.108',1534791682,'__ci_last_regenerate|i:1534791628;identity|s:5:\"admin\";username|s:5:\"admin\";email|s:15:\"admin@admin.com\";user_id|s:1:\"1\";old_last_login|s:10:\"1530389135\";last_check|i:1534791639;'),('72n4ht09jpg15lj4p98i8enpvb8u8r28','149.154.167.169',1534791707,'__ci_last_regenerate|i:1534791706;'),('gp1n4joies5cf14ia8mesic0aj4203uo','185.163.24.79',1534793543,'__ci_last_regenerate|i:1534793541;identity|s:5:\"admin\";username|s:5:\"admin\";email|s:15:\"admin@admin.com\";user_id|s:1:\"1\";old_last_login|s:10:\"1530389135\";last_check|i:1534791639;'),('34pp36tkdso04vg70t28rritjb3vhu2p','88.152.8.123',1534797342,'__ci_last_regenerate|i:1534797290;identity|s:5:\"admin\";username|s:5:\"admin\";email|s:15:\"admin@admin.com\";user_id|s:1:\"1\";old_last_login|s:10:\"1534791639\";last_check|i:1534797303;'),('2ann7cl8k0maekhoj531u4q4o8cckhn7','88.152.8.105',1534843810,'__ci_last_regenerate|i:1534843725;identity|s:5:\"admin\";username|s:5:\"admin\";email|s:15:\"admin@admin.com\";user_id|s:1:\"1\";old_last_login|s:10:\"1534797303\";last_check|i:1534843737;'),('mamovdaa6gcgqtmumh1ssb6f7g29elro','185.163.24.112',1534881415,'__ci_last_regenerate|i:1534881412;'),('ln2mcsl30p8ugdd5h2794l82r2mfbvl8','80.80.221.197',1534998140,'__ci_last_regenerate|i:1534998128;identity|s:5:\"admin\";username|s:5:\"admin\";email|s:15:\"admin@admin.com\";user_id|s:1:\"1\";old_last_login|s:10:\"1534843737\";last_check|i:1534998138;'),('4o7f0rvtdaoamu0vusqasigm2tbsfj49','88.152.8.185',1535380753,'__ci_last_regenerate|i:1535380751;'),('fj6adudjev8b8tnvorqeatatrv1g4b28','88.152.8.142',1535447316,'__ci_last_regenerate|i:1535447314;'),('sobipdofmgnahipamjmp8gd439apet9j','88.152.8.25',1535467289,'__ci_last_regenerate|i:1535467287;'),('cvhtahqmnhllu4n4umb0hrj7oqraa31n','37.233.84.13',1535473078,'__ci_last_regenerate|i:1535472989;identity|s:5:\"admin\";username|s:5:\"admin\";email|s:15:\"admin@admin.com\";user_id|s:1:\"1\";old_last_login|s:10:\"1534998138\";last_check|i:1535473002;'),('fh21uqv4me8o9uis9dp2hos0q9n06me7','149.154.167.166',1535563621,'__ci_last_regenerate|i:1535563620;'),('ucjq0es30c1pihr04fmhaq21u05s7141','195.181.162.103',1535563890,'__ci_last_regenerate|i:1535563629;identity|s:5:\"admin\";username|s:5:\"admin\";email|s:15:\"admin@admin.com\";user_id|s:1:\"1\";old_last_login|s:10:\"1535563759\";last_check|i:1535563788;'),('j6im7g0k1j65vgop9ib2tat4rt0446h6','66.249.83.221',1535563644,'__ci_last_regenerate|i:1535563644;'),('qldsdgj5js9p0imk7ubg20tu08tp813f','66.102.9.21',1535563648,'__ci_last_regenerate|i:1535563648;'),('j1hoqerqfe3566kqvms7hljgfr0jj7l5','185.163.24.122',1535563767,'__ci_last_regenerate|i:1535563648;identity|s:5:\"admin\";username|s:5:\"admin\";email|s:15:\"admin@admin.com\";user_id|s:1:\"1\";old_last_login|s:10:\"1535473002\";last_check|i:1535563759;'),('s7vn5amh4p41iuqmkhu9krdadmjb60sg','185.163.24.99',1539226765,'__ci_last_regenerate|i:1539226755;identity|s:5:\"admin\";username|s:5:\"admin\";email|s:15:\"admin@admin.com\";user_id|s:1:\"1\";old_last_login|s:10:\"1537259135\";last_check|i:1539226760;'),('mflpnu3en5re2q2qjo652d00epusn305','178.218.202.35',1537259137,'__ci_last_regenerate|i:1537259124;identity|s:5:\"admin\";username|s:5:\"admin\";email|s:15:\"admin@admin.com\";user_id|s:1:\"1\";old_last_login|s:10:\"1535563788\";last_check|i:1537259135;'),('icnvpv3tnr8qnsm2b0pmtfutoa1i9ka0','149.154.167.167',1539226727,'__ci_last_regenerate|i:1539226725;'),('uptuc03sckgh5n7tamme7r0ub6suegee','178.218.203.200',1544502557,'__ci_last_regenerate|i:1544502555;'),('crqhkfjarf3tqq8vnbf0kplf5ei8eah1','178.218.203.200',1544502558,'__ci_last_regenerate|i:1544502558;'),('p9qarfa2qqiejbml87h3qu5ni0b5bqr3','178.218.203.200',1544502616,'__ci_last_regenerate|i:1544502563;identity|s:5:\"admin\";username|s:5:\"admin\";email|s:15:\"admin@admin.com\";user_id|s:1:\"1\";old_last_login|s:10:\"1539226760\";last_check|i:1544502570;');
/*!40000 ALTER TABLE `ci_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cities`
--

DROP TABLE IF EXISTS `cities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cities` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(60) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cities`
--

LOCK TABLES `cities` WRITE;
/*!40000 ALTER TABLE `cities` DISABLE KEYS */;
INSERT INTO `cities` VALUES (1,'Andijon'),(2,'Buxoro'),(3,'Navoiy'),(4,'Samarqand'),(5,'Namangan'),(6,'Toshkent'),(7,'Sirdaryo'),(8,'Surxondaryo'),(9,'Qashqadaryo'),(10,'Jizzax'),(11,'Xorazm'),(12,'Farg\'ona'),(13,'Qoraqalpog\'iston Respublikasi');
/*!40000 ALTER TABLE `cities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `corn`
--

DROP TABLE IF EXISTS `corn`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `corn` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `factory_id` int(11) NOT NULL,
  `weight` double NOT NULL,
  `summ` double NOT NULL,
  `pay_summ` double NOT NULL,
  `by_bank` double NOT NULL,
  `by_tax` double NOT NULL,
  `by_self_counting` double NOT NULL,
  `currency_id` int(11) NOT NULL,
  `date` date NOT NULL,
  UNIQUE KEY `id` (`id`),
  KEY `currency_id` (`currency_id`),
  KEY `factory_id` (`factory_id`),
  CONSTRAINT `corn_ibfk_2` FOREIGN KEY (`currency_id`) REFERENCES `currency` (`id`),
  CONSTRAINT `corn_ibfk_3` FOREIGN KEY (`factory_id`) REFERENCES `factory` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Chigit malumotlari saqlanadigan jadval';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `corn`
--

LOCK TABLES `corn` WRITE;
/*!40000 ALTER TABLE `corn` DISABLE KEYS */;
INSERT INTO `corn` VALUES (1,26,25,2000,0,1000,200,600,1,'2018-01-08'),(2,27,20,3000,0,500,1500,500,2,'2017-12-13');
/*!40000 ALTER TABLE `corn` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*DEFINER=`paxtasanoat`@`%`*/ /*!50003 TRIGGER `CornInsert` BEFORE INSERT ON `corn`
 FOR EACH ROW set new.pay_summ=new.by_bank+new.by_tax+new.by_self_counting */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*DEFINER=`paxtasanoat`@`%`*/ /*!50003 TRIGGER `UpdateCorn` BEFORE UPDATE ON `corn`
 FOR EACH ROW set new.pay_summ=new.by_bank+new.by_tax+new.by_self_counting */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `cotton`
--

DROP TABLE IF EXISTS `cotton`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cotton` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `factory_id` int(11) NOT NULL,
  `weight` double NOT NULL,
  `summ` double NOT NULL,
  `pay_summ` double NOT NULL,
  `by_bank` double NOT NULL,
  `by_tax` double NOT NULL,
  `by_self_counting` double NOT NULL,
  `currency_id` int(11) NOT NULL,
  `date` date NOT NULL,
  UNIQUE KEY `id` (`id`),
  KEY `currency_id` (`currency_id`),
  KEY `factory_id` (`factory_id`),
  CONSTRAINT `cotton_ibfk_1` FOREIGN KEY (`currency_id`) REFERENCES `currency` (`id`),
  CONSTRAINT `cotton_ibfk_2` FOREIGN KEY (`factory_id`) REFERENCES `factory` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Paxta momig''i jadvali';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cotton`
--

LOCK TABLES `cotton` WRITE;
/*!40000 ALTER TABLE `cotton` DISABLE KEYS */;
INSERT INTO `cotton` VALUES (3,26,20,100000,202000,2000,50000,150000,3,'2017-10-29'),(4,26,0,0,0,0,0,0,1,'2018-01-23');
/*!40000 ALTER TABLE `cotton` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*DEFINER=`paxtasanoat`@`%`*/ /*!50003 TRIGGER `CottonInsert` BEFORE INSERT ON `cotton`
 FOR EACH ROW set new.pay_summ=new.by_bank+new.by_tax+new.by_self_counting */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*DEFINER=`paxtasanoat`@`%`*/ /*!50003 TRIGGER `updateCotton` BEFORE UPDATE ON `cotton`
 FOR EACH ROW set new.pay_summ=new.by_bank+new.by_tax+new.by_self_counting */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `currency`
--

DROP TABLE IF EXISTS `currency`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `currency` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_bin NOT NULL,
  `code` varchar(6) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `currency`
--

LOCK TABLES `currency` WRITE;
/*!40000 ALTER TABLE `currency` DISABLE KEYS */;
INSERT INTO `currency` VALUES (1,'AQSH dollari','usd'),(2,'So\'m','so\'m'),(3,'Rossiya rubli','rub');
/*!40000 ALTER TABLE `currency` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dislocation`
--

DROP TABLE IF EXISTS `dislocation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dislocation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `factory_id` int(11) NOT NULL,
  `weight` double NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dislocation`
--

LOCK TABLES `dislocation` WRITE;
/*!40000 ALTER TABLE `dislocation` DISABLE KEYS */;
INSERT INTO `dislocation` VALUES (19,28,55,'2017-01-01'),(20,27,88,'2017-02-01'),(21,30,43,'2017-01-01'),(22,26,556,'2016-02-01'),(23,28,43,'2016-12-01'),(24,27,200,'2018-01-01'),(25,29,434,'2017-01-01'),(26,28,324,'2017-06-01'),(27,28,2555,'2017-12-19');
/*!40000 ALTER TABLE `dislocation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `factory`
--

DROP TABLE IF EXISTS `factory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `factory` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) COLLATE utf8_bin NOT NULL,
  `phone` varchar(15) COLLATE utf8_bin NOT NULL,
  `info` text COLLATE utf8_bin NOT NULL,
  `address` varchar(250) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `factory`
--

LOCK TABLES `factory` WRITE;
/*!40000 ALTER TABLE `factory` DISABLE KEYS */;
INSERT INTO `factory` VALUES (26,'New textile','','',''),(27,'Barakatex','','',''),(28,'O\'zbekiston','','',''),(29,'Buxoro Paxta','','',''),(30,'Navoiy Paxta','','',''),(31,'Toshtekstil','','','');
/*!40000 ALTER TABLE `factory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `groups`
--

DROP TABLE IF EXISTS `groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `groups` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `description` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `groups`
--

LOCK TABLES `groups` WRITE;
/*!40000 ALTER TABLE `groups` DISABLE KEYS */;
INSERT INTO `groups` VALUES (1,'superadmin','Super administrator'),(2,'admin','Administrator'),(3,'moderator','Moderator'),(4,'operator','Operator');
/*!40000 ALTER TABLE `groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `login_attempts`
--

DROP TABLE IF EXISTS `login_attempts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `login_attempts` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ip_address` varchar(15) NOT NULL,
  `login` varchar(100) NOT NULL,
  `time` int(11) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `login_attempts`
--

LOCK TABLES `login_attempts` WRITE;
/*!40000 ALTER TABLE `login_attempts` DISABLE KEYS */;
INSERT INTO `login_attempts` VALUES (1,'178.218.203.200','admin@admin.com',1544502566);
/*!40000 ALTER TABLE `login_attempts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staple`
--

DROP TABLE IF EXISTS `staple`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `staple` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `factory_id` int(11) NOT NULL,
  `weight` double NOT NULL,
  `summ` double NOT NULL,
  `pay_summ` double NOT NULL,
  `by_bank` double NOT NULL,
  `by_tax` double NOT NULL,
  `by_self_counting` double NOT NULL,
  `currency_id` int(11) NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`id`),
  KEY `factory_id` (`factory_id`),
  KEY `currency_id` (`currency_id`),
  CONSTRAINT `staple_ibfk_1` FOREIGN KEY (`factory_id`) REFERENCES `factory` (`id`),
  CONSTRAINT `staple_ibfk_2` FOREIGN KEY (`currency_id`) REFERENCES `currency` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staple`
--

LOCK TABLES `staple` WRITE;
/*!40000 ALTER TABLE `staple` DISABLE KEYS */;
INSERT INTO `staple` VALUES (4,27,88,15000000,8500000,3000000,2500000,3000000,1,'2017-12-04'),(5,27,58,7777777,7000000,2000000,2000000,3000000,2,'2017-11-06'),(7,27,50,5000,1500,1000,200,300,1,'2017-11-07'),(8,27,34,2000,150000000,50000000,50000000,50000000,1,'2017-12-04'),(9,27,23,1000,21000000,15000000,5000000,1000000,1,'2017-11-08'),(10,26,22,3000,8600,2200,1200,5200,3,'2017-10-10');
/*!40000 ALTER TABLE `staple` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*DEFINER=`paxtasanoat`@`%`*/ /*!50003 TRIGGER `stapleInsert` BEFORE INSERT ON `staple`
 FOR EACH ROW set new.pay_summ=new.by_bank+new.by_tax+new.by_self_counting */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*DEFINER=`paxtasanoat`@`%`*/ /*!50003 TRIGGER `updateStaple` BEFORE UPDATE ON `staple`
 FOR EACH ROW set new.pay_summ=new.by_bank+new.by_tax+new.by_self_counting */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ip_address` varchar(45) NOT NULL,
  `username` varchar(100) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `salt` varchar(255) DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `activation_code` varchar(40) DEFAULT NULL,
  `forgotten_password_code` varchar(40) DEFAULT NULL,
  `forgotten_password_time` int(11) unsigned DEFAULT NULL,
  `remember_code` varchar(40) DEFAULT NULL,
  `created_on` int(11) unsigned NOT NULL,
  `last_login` int(11) unsigned DEFAULT NULL,
  `active` tinyint(1) unsigned DEFAULT NULL,
  `first_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `company` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `sex` enum('1','0','','') NOT NULL DEFAULT '1',
  `city` varchar(120) NOT NULL,
  `born` date NOT NULL,
  `image_file` varchar(120) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'127.0.0.1','admin','$2y$08$7I5bJ26vMhWPEWe0BBmV..hq.Irxgy.5SuEbEboudkwCmevgw22zC','','admin@admin.com','',NULL,NULL,'Uf0/EB6ongmZLICmN/zpl.',1268889823,1544502570,1,'Admin','Istrator','ADMIN','+998983090094','','Buxoro','1994-09-09','4d19dc407f9d433da35ac12fd92c5379.png');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users_groups`
--

DROP TABLE IF EXISTS `users_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users_groups` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `group_id` mediumint(8) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uc_users_groups` (`user_id`,`group_id`),
  KEY `fk_users_groups_users1_idx` (`user_id`),
  KEY `fk_users_groups_groups1_idx` (`group_id`),
  CONSTRAINT `fk_users_groups_groups1` FOREIGN KEY (`group_id`) REFERENCES `groups` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  CONSTRAINT `fk_users_groups_users1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users_groups`
--

LOCK TABLES `users_groups` WRITE;
/*!40000 ALTER TABLE `users_groups` DISABLE KEYS */;
INSERT INTO `users_groups` VALUES (1,1,1),(2,1,2);
/*!40000 ALTER TABLE `users_groups` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-12-11  9:36:44

